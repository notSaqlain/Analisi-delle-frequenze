## Informazioni

1. Devo leggere un file .txt un linea alla volta
2. Ogni linea viene divisa parola per parola
3. Per ogni parola controllo che non ci siano caratteri di punteggiatura (es. , ; : ! ?)
4. Inserisco le parole nella hashmap per l'analisi di frequenza <-- da fare dopo insieme
